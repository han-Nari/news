let activePage = window.location.pathname;
let navLinks = document.querySelectorAll('a');

navLinks.forEach(item => {
    if(item.href.includes(`${activePage}`)) {
        item.classList.add('active');
    }
});

let navBtn = document.querySelector('.bar');
let sideBar = document.querySelector('nav');
let ul = document.querySelector('ul');
let changeIcon = document.querySelector('.fa-bars');
let main = document.querySelector('main');

navBtn.addEventListener('click', () => {
    main.classList.toggle('slide');
});

let closed = document.querySelector('.closed');
    closed.addEventListener('click', ()=> {
    main.classList.remove('slide');
});


let down = document.querySelector('.down');
let drp_menu = document.querySelector('.drp_menu');

down.addEventListener('click', () => {
	drp_menu.classList.toggle('out');
});

document.onclick = function(e) {
	if(down !== e.target && drp_menu !== e.target) {
		drp_menu.classList.remove('out');
	}
}

function showTime(){
    var date = new Date();
    var h = date.getHours(); // 0 - 23
    var m = date.getMinutes(); // 0 - 59
    var s = date.getSeconds(); // 0 - 59
    var session = "AM";
    
    if(h == 0){
        h = 12;
    }
    
    if(h > 12){
        h = h - 12;
        session = "PM";
    }
    
    h = (h < 10) ? "0" + h : h;
    m = (m < 10) ? "0" + m : m;
    s = (s < 10) ? "0" + s : s;
    
    var time = h + ":" + m + ":" + s + " " + session;
    document.getElementById("MyClockDisplay").innerText = time;
    document.getElementById("MyClockDisplay").textContent = time;
    
    setTimeout(showTime, 1000);
    
}

showTime();


